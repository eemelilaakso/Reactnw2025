import './App.css';
import React from 'react';


const Viesti = (props) => (
    <>
        <p>{props.teksti}</p>

    </>
  );

export default Viesti;